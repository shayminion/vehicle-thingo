﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vehicle_Renting.Classes;
using Vehicle_Renting.Services;
using System.Configuration;

namespace Vehicle_Renting.Services
{
    public class JourneyService
    {
        public Journey UpdateJourneyParameters (Journey journey)
        {
            
        }
    }
}
