﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehicle_Renting.Classes
{
    class Journey
    {
        private string totalKm { get; set; }

        private string totalServices { get; set; }

        private string RequiredService { get; set; }
    }
}
